# Portafolio Profesional - Jeannete Collao

👩‍💼 **Ingeniería en Control de Gestión y Análisis de Datos**  
Institución: **Kibernum**  
Año: **2025**

---

## 📘 Presentación Personal
Soy **Jeannete Collao**, profesional en **Ingeniería en Control de Gestión y Análisis de Datos**, con formación en Kibernum (2025).  
Me especializo en el **análisis financiero y de datos**, desarrollo de **KPI estratégicos** y **visualización de información** con herramientas como **Power BI, Excel avanzado y Python**.  

Mi objetivo profesional es contribuir al crecimiento de las organizaciones, optimizando procesos y apoyando la **toma de decisiones estratégicas** a través del uso inteligente de los datos.

---

## 🧩 Proyectos Destacados

### 1. Dashboard de Control Presupuestario  
- **Descripción:** Desarrollo de un panel interactivo para el seguimiento de presupuestos en tiempo real.  
- **Objetivo:** Optimizar el control financiero y detectar desviaciones de manera oportuna.  
- **Tecnologías:** Power BI, Excel avanzado.  
- **Reflexión:** Aprendí a transformar información dispersa en reportes claros y útiles para la gestión estratégica.  

---

### 2. Análisis de Ventas con Python y Pandas  
- **Descripción:** Procesamiento y análisis de datos de ventas para identificar patrones y tendencias.  
- **Objetivo:** Apoyar decisiones comerciales basadas en datos y segmentación de clientes.  
- **Tecnologías:** Python, Pandas, Matplotlib.  
- **Reflexión:** Fortalecí mis habilidades de programación y descubrí la importancia de la analítica para comprender el comportamiento del mercado.  

---

### 3. Indicadores KPI para Control de Gestión  
- **Descripción:** Diseño e implementación de indicadores clave de desempeño alineados con los objetivos de la organización.  
- **Objetivo:** Medir y monitorear el cumplimiento de metas estratégicas.  
- **Tecnologías:** Excel, Power BI.  
- **Reflexión:** Reforcé mi capacidad para vincular métricas operativas con objetivos estratégicos, mejorando la gestión integral.  

---

## 📬 Contacto Profesional
- 📧 **Email:** jeannete.collao@example.com  
- 🔗 **LinkedIn:** [linkedin.com/in/jeannete-collao](https://linkedin.com/in/jeannete-collao)  
- 💻 **GitHub:** [github.com/jeannete-collao](https://github.com/jeannete-collao)  

---

## 🚀 Publicación en GitHub Pages
1. Crear un repositorio llamado `jeannete-collao-portafolio`.  
2. Subir los archivos `index.html` y `README.md`.  
3. Ir a **Settings → Pages**, seleccionar la rama `main` y la carpeta `/ (root)`.  
4. Guardar cambios y acceder al enlace:  
   👉 `https://<usuario>.github.io/jeannete-collao-portafolio/`

---

© 2025 Jeannete Collao · Kibernum
